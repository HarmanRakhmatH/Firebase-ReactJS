import { createStore, applyMiddleware } from "redux";
import reducer from "../reducer";
import thunk from "redux-thunk";


export const store = createStore(reducer, applyMiddleware(thunk))
// export const store = createStore(reducer)


// export default store;

// kao export defaullt itu nanti penguana tidak pakai kurng kurawal , karna di folder pages app index js tidak menggunakan kurung kurawal jadi export biasa saja tanpa tambahan default 