export * from './store';



// artinya saya meng eksport apa adanya yang ada di folder store ini 

// namun karna kita sudah pasang export all from './store' di folder redux config jadi hanya perlu panggil redux saja

