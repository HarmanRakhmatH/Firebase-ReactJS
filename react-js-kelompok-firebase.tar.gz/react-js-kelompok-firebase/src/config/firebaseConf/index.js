import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'; // authentication untuk login 
// import 'firebase/compat/firestore'; // firestore untuk menyimpan database n
// import 'dotenv/config'

// const firebaseConfig = {
//     apiKey: process.env.API_KEY,
//     authDomain: process.env.AUTH_DOMAIN,
//     projectId: process.env.PROJECT_ID,
//     storageBucket: process.env.STORAGE_BUCKET,
//     messagingSenderId: process.env.MESSAGING_SENDER_ID,
//     appId: process.env.APP_ID,
//     measurementId: process.env.MEASUREMENT
// };
const firebaseConfig = {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: "",
    measurementId: ""
};




// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// const analytics = firebase.getAnalytics(app);


export default firebase