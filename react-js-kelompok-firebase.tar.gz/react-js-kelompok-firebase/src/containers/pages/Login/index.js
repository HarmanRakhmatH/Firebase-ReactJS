import React, { Component } from "react";
import { connect } from 'react-redux'
import { actionUserName } from "../../../config/redux/action";

class Login extends Component {
    changeUser = () => {
        this.props.changeUserName()
    }
    render() {
        return (
            <div>
                <p>Login Page {this.props.userName}</p>
                <button onClick={this.changeUser}>Change User Name</button>
                <button>Go to Dashboard</button>
            </div>
        )
    }
}
// nilaianya dari this.props.popupProps adalah state.popup key objext popupPRops di ambil dari index js page appp dari variable intialstate key popup value false

// versi pertama arrow function
// const actionUserName = () => {
//     return (dispatch) => {
//         setTimeout(() => {
//             return dispatch({ type: 'CHANGE_USER', value: 'Harman Rakhmat' })
//         }, 2000)
//     }

// }
// versi kedua arrow function move to filder redux in folder action file index.js
// const actionUserName = () => (dispatch) => {
//     setTimeout(() => {
//         return dispatch({ type: 'CHANGE_USER', value: 'Harman Rakhmat' })
//     }, 2000)
// }


const reduxState = (state) => ({
    popupProps: state.popup,
    userName: state.user
})

const reduxDispatch = (dispatch) => ({
    changeUserName: () => dispatch(actionUserName())
})

export default connect(reduxState, reduxDispatch)(Login);