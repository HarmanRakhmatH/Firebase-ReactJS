import './App.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom"
import Dashboard from '../Dashboard';
import Login from '../Login';
import Register from '../Register';
// import { createStore } from '@reduxjs/toolkit';
// import { configureStore } from '@reduxjs/toolkit';
// import { createStore } from 'redux'
// import { configureStore } from 'redux'
import { Provider } from 'react-redux';
import { store } from '../../../config/redux'

// const store = configureStore(reducer)
function App() {
  return (
    <Provider store={store}>
      <Router>
        <div>
          <Route path="/" exact component={Dashboard} />
          <Route path="/login/" component={Login} />
          <Route path="/register/" component={Register} />
        </div>
      </Router>
    </Provider>
  );
}

export default App;
